package com.example.Insurance.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
