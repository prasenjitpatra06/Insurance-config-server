package com.example.Insurance.provider.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
